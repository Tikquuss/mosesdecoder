// Visual C++ seems to prefer a .cpp extension to .cc
#include "gc_cpp.cc"
